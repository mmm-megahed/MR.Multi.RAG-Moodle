define(['jquery', 'core/ajax', 'core/notification'], function($, Ajax, Notification) {
    
    return {
        init: function(courseid) {
            var self = this;
            self.courseid = courseid;
            self.chatHistory = [];
            
            // Initialize event handlers
            self.initProcessForm();
            self.initSearchForm();
            self.initChatForm();
            self.initTabSwitching();
            
            // Load chat history from session storage (if available)
            self.loadChatHistory();
        },
        
        initTabSwitching: function() {
            // Handle tab switching with Bootstrap classes
            $('[data-bs-toggle="tab"]').on('click', function(e) {
                e.preventDefault();
                var target = $(this).attr('data-bs-target');
                
                // Remove active classes
                $('.tab-pane').removeClass('show active');
                $('.nav-link').removeClass('active');
                
                // Add active classes
                $(target).addClass('show active');
                $(this).addClass('active');
            });
        },
        
        initProcessForm: function() {
            var self = this;
            
            $('.process-form').on('submit', function(e) {
                var $btn = $('#process-btn');
                var $status = $('#process-status');
                
                $btn.prop('disabled', true);
                $btn.html('<i class="fa fa-spinner fa-spin me-1"></i> Processing...');
                $status.html('<div class="alert alert-info">Processing files, please wait...</div>');
                
                // Form will submit normally, this just provides UI feedback
            });
        },
        
        initSearchForm: function() {
            var self = this;
            
            $('.search-form').on('submit', function(e) {
                e.preventDefault();
                
                var query = $('#search-input').val().trim();
                var limit = $('#search-limit').val();
                
                if (!query) {
                    Notification.addNotification({
                        message: 'Please enter a search query',
                        type: 'error'
                    });
                    return;
                }
                
                self.performSearch(query, limit);
            });
            
            // Search on Enter key
            $('#search-input').on('keypress', function(e) {
                if (e.which === 13) {
                    $('.search-form').submit();
                }
            });
        },
        
        initChatForm: function() {
            var self = this;
            
            $('.chat-form').on('submit', function(e) {
                e.preventDefault();
                
                var query = $('#chat-input').val().trim();
                
                if (!query) {
                    Notification.addNotification({
                        message: 'Please enter a question',
                        type: 'error'
                    });
                    return;
                }
                
                self.performChat(query);
                $('#chat-input').val('');
            });
            
            // Clear chat history
            $('#clear-chat-btn').on('click', function() {
                self.clearChatHistory();
            });
            
            // Chat on Enter key
            $('#chat-input').on('keypress', function(e) {
                if (e.which === 13) {
                    $('.chat-form').submit();
                }
            });
        },
        
        performSearch: function(query, limit) {
            var self = this;
            var $btn = $('#search-btn');
            var $results = $('#search-results');
            
            $btn.prop('disabled', true);
            $btn.html('<i class="fa fa-spinner fa-spin me-1"></i> Searching...');
            $results.html('<div class="text-center"><i class="fa fa-spinner fa-spin"></i> Searching...</div>');
            
            $.ajax({
                url: M.cfg.wwwroot + '/blocks/multimodalrag/api.php',
                method: 'POST',
                data: {
                    action: 'search',
                    courseid: self.courseid,
                    text: query,
                    limit: limit,
                    sesskey: M.cfg.sesskey
                },
                dataType: 'json'
            }).done(function(response) {
                if (response.success) {
                    self.displaySearchResults(response.results, query);
                } else {
                    $results.html('<div class="alert alert-danger">Search failed. Please try again.</div>');
                }
            }).fail(function() {
                $results.html('<div class="alert alert-danger">Search request failed. Please check your connection.</div>');
            }).always(function() {
                $btn.prop('disabled', false);
                $btn.html('<i class="fa fa-search me-1"></i> Search');
            });
        },
        
        performChat: function(query) {
            var self = this;
            var $btn = $('#chat-btn');
            var $history = $('#chat-history');
            
            // Add user message to chat
            self.addChatMessage('user', query);
            
            $btn.prop('disabled', true);
            $btn.html('<i class="fa fa-spinner fa-spin me-1"></i> Thinking...');
            
            // Add thinking indicator
            var thinkingId = 'thinking-' + Date.now();
            self.addChatMessage('assistant', '<i class="fa fa-spinner fa-spin"></i> Thinking...', thinkingId);
            
            $.ajax({
                url: M.cfg.wwwroot + '/blocks/multimodalrag/api.php',
                method: 'POST',
                data: {
                    action: 'chat',
                    courseid: self.courseid,
                    text: query,
                    limit: 10,
                    sesskey: M.cfg.sesskey
                },
                dataType: 'json'
            }).done(function(response) {
                // Remove thinking indicator
                $('#' + thinkingId).remove();
                
                if (response.success) {
                    self.addChatMessage('assistant', response.answer);
                    self.saveChatHistory();
                } else {
                    self.addChatMessage('assistant', 'Sorry, I encountered an error while processing your question. Please try again.');
                }
            }).fail(function() {
                $('#' + thinkingId).remove();
                self.addChatMessage('assistant', 'Sorry, I could not connect to the chat service. Please try again later.');
            }).always(function() {
                $btn.prop('disabled', false);
                $btn.html('<i class="fa fa-paper-plane me-1"></i> Ask');
            });
        },
        
        displaySearchResults: function(results, query) {
            var $results = $('#search-results');
            
            if (!results || results.length === 0) {
                $results.html('<div class="alert alert-info">No results found for "' + $('<div>').text(query).html() + '"</div>');
                return;
            }
            
            var html = '<div class="search-results-container">';
            html += '<h5 class="mb-3">Search Results (' + results.length + ')</h5>';
            
            results.forEach(function(result, index) {
                html += '<div class="search-result-item card mb-3">';
                html += '<div class="card-body">';
                html += '<div class="d-flex justify-content-between align-items-start">';
                html += '<h6 class="card-title mb-2">Result ' + (index + 1) + '</h6>';
                if (result.score) {
                    html += '<span class="badge bg-primary">Score: ' + (result.score * 100).toFixed(1) + '%</span>';
                }
                html += '</div>';
                html += '<p class="card-text">' + $('<div>').text(result.content || result.text || 'No content available').html() + '</p>';
                if (result.metadata) {
                    html += '<small class="text-muted">Source: ' + $('<div>').text(result.metadata.source || 'Unknown').html() + '</small>';
                }
                html += '</div></div>';
            });
            
            html += '</div>';
            $results.html(html);
        },
        
        addChatMessage: function(sender, message, id) {
            var self = this;
            var $history = $('#chat-history');
            var timestamp = new Date().toLocaleTimeString();
            var messageId = id || 'msg-' + Date.now();
            
            var senderLabel = sender === 'user' ? 'You' : 'Assistant';
            var senderClass = sender === 'user' ? 'user-message' : 'assistant-message';
            var alignClass = sender === 'user' ? 'text-end' : 'text-start';
            var bgClass = sender === 'user' ? 'bg-primary text-white' : 'bg-light';
            
            var html = '<div class="chat-message mb-3 ' + alignClass + '" id="' + messageId + '">';
            html += '<div class="d-inline-block p-3 rounded ' + bgClass + '" style="max-width: 80%;">';
            html += '<div class="fw-bold mb-1">' + senderLabel + '</div>';
            html += '<div class="message-content">' + message + '</div>';
            html += '<small class="opacity-75 d-block mt-1">' + timestamp + '</small>';
            html += '</div></div>';
            
            $history.append(html);
            $history.scrollTop($history[0].scrollHeight);
            
            // Store in chat history
            if (!id) { // Don't store temporary messages like "thinking"
                self.chatHistory.push({
                    sender: sender,
                    message: message,
                    timestamp: timestamp
                });
            }
        },
        
        clearChatHistory: function() {
            var self = this;
            $('#chat-history').empty();
            self.chatHistory = [];
            self.saveChatHistory();
        },
        
        loadChatHistory: function() {
            var self = this;
            // In a real implementation, you might load from server or localStorage
            // For now, we'll start with empty history
            self.chatHistory = [];
        },
        
        saveChatHistory: function() {
            var self = this;
            // In a real implementation, you might save to server or localStorage
            // For now, we'll just keep it in memory
        }
    };
});
