<?php
require_once('../../config.php');
require_once($CFG->libdir . '/filelib.php');

// Handle CORS for AJAX requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    exit(0);
}

header('Content-Type: application/json');

$action = required_param('action', PARAM_ALPHA);
$courseid = required_param('courseid', PARAM_INT);

require_login();

$course = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);
$context = context_course::instance($courseid);

$fastapi_url = rtrim(get_config('block_multimodalrag', 'fastapi_url') ?: 'http://fastapi:8000', '/');

try {
    switch ($action) {
        case 'search':
            require_capability('block/multimodalrag:search', $context);
            
            $text = required_param('text', PARAM_TEXT);
            $limit = optional_param('limit', 10, PARAM_INT);
            
            $result = search_content($fastapi_url, $courseid, $text, $limit);
            echo json_encode($result);
            break;
            
        case 'chat':
            require_capability('block/multimodalrag:chat', $context);
            
            $text = required_param('text', PARAM_TEXT);
            $limit = optional_param('limit', 10, PARAM_INT);
            
            $result = chat_with_content($fastapi_url, $courseid, $text, $limit);
            echo json_encode($result);
            break;
            
        default:
            throw new Exception('Invalid action');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}

function search_content($fastapi_url, $courseid, $text, $limit) {
    $data = json_encode([
        'text' => $text,
        'limit' => $limit
    ]);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => "{$fastapi_url}/api/v1/nlp/index/search/{$courseid}",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        throw new Exception('Search request failed');
    }
    
    $result = json_decode($response, true);
    if (!$result || $result['signal'] !== 'VECTORDB_SEARCH_SUCCESS') {
        throw new Exception('Search failed');
    }
    
    return [
        'success' => true,
        'results' => $result['results']
    ];
}

function chat_with_content($fastapi_url, $courseid, $text, $limit) {
    $data = json_encode([
        'text' => $text,
        'limit' => $limit
    ]);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => "{$fastapi_url}/api/v1/nlp/index/answer/{$courseid}",
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 60,
        CURLOPT_CONNECTTIMEOUT => 10
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code !== 200) {
        throw new Exception('Chat request failed');
    }
    
    $result = json_decode($response, true);
    if (!$result || $result['signal'] !== 'RAG_ANSWER_SUCCESS') {
        throw new Exception('Chat failed');
    }
    
    return [
        'success' => true,
        'answer' => $result['answer'],
        'full_prompt' => $result['full_prompt'] ?? '',
        'chat_history' => $result['chat_history'] ?? []
    ];
}
?>
