<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Multimodal RAG';
$string['multimodalrag'] = 'Multimodal RAG';
$string['multimodalrag:addinstance'] = 'Add Multimodal RAG block';
$string['multimodalrag:processfiles'] = 'Process course files';
$string['multimodalrag:search'] = 'Search course content';
$string['multimodalrag:chat'] = 'Chat with course content';

// Main interface
$string['process_files'] = 'Process Files';
$string['search_content'] = 'Search Content';
$string['chat_assistant'] = 'Chat Assistant';

// Processing
$string['processing'] = 'Processing...';
$string['success'] = 'Files processed successfully!';
$string['error'] = 'Processing failed. Please try again.';
$string['no_files'] = 'No files found in this course.';
$string['files_found'] = '{$a} file(s) found to process';

// Search
$string['search_placeholder'] = 'Search course materials...';
$string['search_button'] = 'Search';
$string['search_results'] = 'Search Results';
$string['no_results'] = 'No results found for your search.';
$string['search_limit'] = 'Max results';

// Chat
$string['chat_placeholder'] = 'Ask a question about the course materials...';
$string['chat_button'] = 'Ask';
$string['chat_history'] = 'Chat History';
$string['clear_chat'] = 'Clear Chat';
$string['thinking'] = 'Thinking...';
$string['you'] = 'You';
$string['assistant'] = 'Assistant';

// Tabs
$string['tab_process'] = 'Process';
$string['tab_search'] = 'Search';
$string['tab_chat'] = 'Chat';

// Status messages
$string['not_processed'] = 'Files need to be processed first.';
$string['processed_ready'] = 'Ready to search and chat!';
