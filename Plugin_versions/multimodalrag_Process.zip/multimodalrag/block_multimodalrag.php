<?php
defined('MOODLE_INTERNAL') || die();

class block_multimodalrag extends block_base {
    
    public function init() {
        $this->title = get_string('pluginname', 'block_multimodalrag');
    }

    public function get_content() {
        global $COURSE, $PAGE, $OUTPUT, $USER;

        if ($this->content !== null) {
            return $this->content;
        }

        $this->content = new stdClass();
        $courseid = $COURSE->id;

        // Skip for site course
        if ($courseid <= 1) {
            $this->content->text = '';
            return $this->content;
        }

        // Include CSS and JS
        $PAGE->requires->css('/blocks/multimodalrag/styles/styles.css');
        $PAGE->requires->js_call_amd('block_multimodalrag/main', 'init', [$courseid]);

        // Check capabilities
        $can_process = has_capability('block/multimodalrag:processfiles', $this->context);
        $can_search = has_capability('block/multimodalrag:search', $this->context);
        $can_chat = has_capability('block/multimodalrag:chat', $this->context);

        if (!$can_process && !$can_search && !$can_chat) {
            $this->content->text = '';
            return $this->content;
        }

        // Get file count and processing status
        $filecount = $this->count_course_files($courseid);
        $is_processed = $this->is_course_processed($courseid);

        $this->content->text = $this->render_interface($courseid, $filecount, $is_processed, 
                                                      $can_process, $can_search, $can_chat);

        return $this->content;
    }

    private function render_interface($courseid, $filecount, $is_processed, $can_process, $can_search, $can_chat) {
        global $OUTPUT;
        
        $tabs = [];
        $content = '';
        
        // Process tab
        if ($can_process) {
            $tabs[] = ['process', get_string('tab_process', 'block_multimodalrag')];
            $content .= $this->render_process_tab($courseid, $filecount);
        }
        
        // Search tab
        if ($can_search && ($is_processed || $filecount > 0)) {
            $tabs[] = ['search', get_string('tab_search', 'block_multimodalrag')];
            $content .= $this->render_search_tab($courseid, $is_processed);
        }
        
        // Chat tab
        if ($can_chat && ($is_processed || $filecount > 0)) {
            $tabs[] = ['chat', get_string('tab_chat', 'block_multimodalrag')];
            $content .= $this->render_chat_tab($courseid, $is_processed);
        }

        if (empty($tabs)) {
            return '<div class="alert alert-info">' . get_string('no_files', 'block_multimodalrag') . '</div>';
        }

        // Render tabbed interface
        $html = '<div class="multimodalrag-block" data-courseid="' . $courseid . '">';
        
        if (count($tabs) > 1) {
            $html .= '<ul class="nav nav-tabs" role="tablist">';
            foreach ($tabs as $i => $tab) {
                $active = $i === 0 ? 'active' : '';
                $html .= '<li class="nav-item" role="presentation">';
                $html .= '<button class="nav-link ' . $active . '" data-bs-toggle="tab" data-bs-target="#tab-' . $tab[0] . '" type="button" role="tab">';
                $html .= $tab[1];
                $html .= '</button></li>';
            }
            $html .= '</ul>';
        }
        
        $html .= '<div class="tab-content">';
        $html .= $content;
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    private function render_process_tab($courseid, $filecount) {
        if ($filecount === 0) {
            return '<div class="tab-pane fade show active" id="tab-process" role="tabpanel">' .
                   '<div class="alert alert-info">' . get_string('no_files', 'block_multimodalrag') . '</div>' .
                   '</div>';
        }

        $processurl = new moodle_url('/blocks/multimodalrag/process.php');
        
        return '<div class="tab-pane fade show active" id="tab-process" role="tabpanel">
                    <div class="process-section">
                        <div class="mb-3">
                            <div class="d-flex align-items-center">
                                <i class="fa fa-file-text-o me-2"></i>
                                <span>' . get_string('files_found', 'block_multimodalrag', $filecount) . '</span>
                            </div>
                        </div>
                        <form method="post" action="' . $processurl . '" class="process-form">
                            <input type="hidden" name="courseid" value="' . $courseid . '">
                            <input type="hidden" name="sesskey" value="' . sesskey() . '">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="chunk_size" class="form-label">Chunk Size</label>
                                    <input type="number" class="form-control" id="chunk_size" name="chunk_size" value="200" min="50" max="1000">
                                </div>
                                <div class="col-md-6">
                                    <label for="overlap_size" class="form-label">Overlap Size</label>
                                    <input type="number" class="form-control" id="overlap_size" name="overlap_size" value="20" min="0" max="100">
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="do_reset" name="do_reset" value="1">
                                    <label class="form-check-label" for="do_reset">
                                        Reset existing data
                                    </label>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" id="process-btn">
                                <i class="fa fa-cog me-1"></i>
                                ' . get_string('process_files', 'block_multimodalrag') . '
                            </button>
                        </form>
                        <div id="process-status" class="mt-3"></div>
                    </div>
                </div>';
    }

    private function render_search_tab($courseid, $is_processed) {
        $disabled = !$is_processed ? 'disabled' : '';
        $alert = !$is_processed ? '<div class="alert alert-warning">' . get_string('not_processed', 'block_multimodalrag') . '</div>' : '';
        
        return '<div class="tab-pane fade" id="tab-search" role="tabpanel">
                    <div class="search-section">
                        ' . $alert . '
                        <form class="search-form mb-3">
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="search-input" 
                                           placeholder="' . get_string('search_placeholder', 'block_multimodalrag') . '" ' . $disabled . '>
                                </div>
                                <div class="col-md-2">
                                    <select class="form-select" id="search-limit" ' . $disabled . '>
                                        <option value="5">5 results</option>
                                        <option value="10" selected>10 results</option>
                                        <option value="20">20 results</option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="btn btn-primary w-100" id="search-btn" ' . $disabled . '>
                                        <i class="fa fa-search me-1"></i>
                                        ' . get_string('search_button', 'block_multimodalrag') . '
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div id="search-results"></div>
                    </div>
                </div>';
    }

    private function render_chat_tab($courseid, $is_processed) {
        $disabled = !$is_processed ? 'disabled' : '';
        $alert = !$is_processed ? '<div class="alert alert-warning">' . get_string('not_processed', 'block_multimodalrag') . '</div>' : '';
        
        return '<div class="tab-pane fade" id="tab-chat" role="tabpanel">
                    <div class="chat-section">
                        ' . $alert . '
                        <div class="chat-container">
                            <div id="chat-history" class="chat-history mb-3"></div>
                            <form class="chat-form">
                                <div class="row">
                                    <div class="col-md-10">
                                        <input type="text" class="form-control" id="chat-input" 
                                               placeholder="' . get_string('chat_placeholder', 'block_multimodalrag') . '" ' . $disabled . '>
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary w-100" id="chat-btn" ' . $disabled . '>
                                            <i class="fa fa-paper-plane me-1"></i>
                                            ' . get_string('chat_button', 'block_multimodalrag') . '
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <div class="mt-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary" id="clear-chat-btn" ' . $disabled . '>
                                    <i class="fa fa-trash me-1"></i>
                                    ' . get_string('clear_chat', 'block_multimodalrag') . '
                                </button>
                            </div>
                        </div>
                    </div>
                </div>';
    }

    private function count_course_files($courseid) {
        global $DB;
        
        $sql = "SELECT COUNT(f.id)
                FROM {course_modules} cm
                JOIN {context} ctx ON ctx.contextlevel = 70 AND ctx.instanceid = cm.id
                JOIN {modules} m ON cm.module = m.id
                JOIN {files} f ON f.contextid = ctx.id
                WHERE cm.course = ? 
                  AND m.name = 'resource'
                  AND f.mimetype IN ('text/plain', 'application/pdf')
                  AND f.filename != '.'
                  AND f.filesize > 0";
        
        return $DB->count_records_sql($sql, [$courseid]);
    }

    private function is_course_processed($courseid) {
        // You might want to implement a way to track processing status
        // For now, we'll assume if files exist, they might be processed
        return $this->count_course_files($courseid) > 0;
    }

    public function applicable_formats() {
        return array('course-view' => true);
    }
}
