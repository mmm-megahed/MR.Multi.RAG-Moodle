<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2024072800;
$plugin->requires  = 2022112800;
$plugin->component = 'block_multimodalrag';
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.1.0';
