<?php
defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    $settings->add(new admin_setting_configtext(
        'block_multimodalrag/fastapi_url',
        'FastAPI URL',
        'FastAPI base URL (e.g., http://fastapi:8000)',
        'http://fastapi:8000',
        PARAM_URL
    ));
    
    $settings->add(new admin_setting_configtext(
        'block_multimodalrag/default_chunk_size',
        'Default Chunk Size',
        'Default chunk size for processing files',
        '200',
        PARAM_INT
    ));
    
    $settings->add(new admin_setting_configtext(
        'block_multimodalrag/default_overlap_size',
        'Default Overlap Size',
        'Default overlap size for processing files',
        '20',
        PARAM_INT
    ));
    
    $settings->add(new admin_setting_configtext(
        'block_multimodalrag/default_search_limit',
        'Default Search Limit',
        'Default number of search results to return',
        '10',
        PARAM_INT
    ));
}
