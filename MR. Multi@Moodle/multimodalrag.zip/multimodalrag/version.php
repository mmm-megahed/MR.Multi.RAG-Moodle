<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'block_multimodalrag';
$plugin->version = 2024072900;
$plugin->requires = 2020061500;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = 'v1.0';
?>